const barangData = [
    { kode: '001', nama: 'A', harga: 10000 },
    { kode: '002', nama: 'B', harga: 20000 },
    { kode: '003', nama: 'C', harga: 30000 }
];


function tampilkanBarang() {
    const barangTabel = document.getElementById('barangTabel');
    barangData.forEach((barang, index) => {
        const row = barangTabel.insertRow(index + 1);
        const kodeCell = row.insertCell(0);
        const namaCell = row.insertCell(1);
        const hargaCell = row.insertCell(2);
        kodeCell.textContent = barang.kode;
        namaCell.textContent = barang.nama;
        hargaCell.textContent = barang.harga;
    });
}

document.addEventListener('DOMContentLoaded', () => {
    tampilkanBarang();
});

 function tambahData(event) {
    event.preventDefault();

    const kode = document.getElementById('kode');
    const quantity = document.getElementById('quantity');
    const selectedBarang = barangData.find(barang => barang.kode === kode.value);

    if (!selectedBarang) {
        alert('Kode barang salah!!');
        return;
    } 

    const jumlah = parseInt(quantity.value);
    const totalHarga = selectedBarang.harga * jumlah;

    const bayar = window.prompt(
        'Total : ' + totalHarga + '\n\n' + 'Masukkan jumlah uang anda:'
    );

    if (bayar === null || bayar === '') {
        alert('Pembayaran gagal');
        return;
    } 

    const totalBayar = parseFloat(bayar);

    if (isNaN(totalBayar) || totalBayar < totalHarga) {
        alert('Jumlah pembayaran tidak valid atau kurang dari total yang harus dibayar');
        return;
    }

    const kembalian = totalBayar - totalHarga;

    alert('Total : ' + totalHarga + '\n' + 'Jumlah yang dibayarkan: ' + totalBayar + '\n' +'Kembalian: ' + kembalian
    );
 }


